var dir_17f6908b029dd3e2044bbf4b56543741 =
[
    [ "problem_1_client.c", "problem__1__client_8c.html", "problem__1__client_8c" ],
    [ "problem_1_server.c", "problem__1__server_8c.html", "problem__1__server_8c" ],
    [ "problem_2.c", "problem__2_8c.html", "problem__2_8c" ]
];