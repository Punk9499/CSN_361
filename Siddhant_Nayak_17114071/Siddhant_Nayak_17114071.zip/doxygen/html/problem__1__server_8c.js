var problem__1__server_8c =
[
    [ "MAX", "problem__1__server_8c.html#a392fb874e547e582e9c66a08a1f23326", null ],
    [ "PORT", "problem__1__server_8c.html#a614217d263be1fb1a5f76e2ff7be19a2", null ],
    [ "SA", "problem__1__server_8c.html#a1e43924adac4ae865aa0acf79710261c", null ],
    [ "func", "problem__1__server_8c.html#ac17020a38607ab29ce18939d5194a32a", null ],
    [ "main", "problem__1__server_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ]
];